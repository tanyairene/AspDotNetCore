﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AmazingAdventures.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace AmazingAdventures.Controllers
{
    [Authorize]
    public class AdminController : Controller
    {
        private IAdventureRepository repository;

        public AdminController(IAdventureRepository repo)
        {
            repository = repo;
        }
        public ViewResult Index() => View(repository.Adventures);

        public ViewResult Edit(int adventureId) =>
            View(repository.Adventures
                .FirstOrDefault(p => p.AdventureId == adventureId));

        [HttpPost]
        public IActionResult Edit(Adventure adventure)
        {
            if (ModelState.IsValid)
            {
                repository.SaveAdventure(adventure);
                TempData["message"] = $"{adventure.Name} has been saved";
                return RedirectToAction("Index");
            }
            else
            {
                //there is something wrong with the data values
                return View(adventure);
            }
        }
        public ViewResult Create() => View("Edit", new Adventure());

        [HttpPost]
        public IActionResult Delete(int adventureId)
        {
            Adventure deletedAdventure = repository.DeleteAdventure(adventureId);
            if(deletedAdventure != null)
            {
                TempData["message"] = $"{deletedAdventure.Name} was deleted";
            }
            return RedirectToAction("Index");
        }
    }
}
