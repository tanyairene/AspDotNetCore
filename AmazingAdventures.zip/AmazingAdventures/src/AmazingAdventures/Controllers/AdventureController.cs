﻿using AmazingAdventures.Models;
using AmazingAdventures.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace AmazingAdventures.Controllers
{
    public class AdventureController : Controller
    {   
        private IAdventureRepository repository;
        public int PageSize = 3;
        public AdventureController(IAdventureRepository repo)
        {
            repository = repo;
        }

        public ViewResult List(string category, int page = 1)
            => View(new AdventuresListViewModel
            {
                Adventures = repository.Adventures
                .Where(p => category == null || p.Category == category)
                .OrderBy(p => p.AdventureId)
                .Skip((page - 1) * PageSize)
                .Take(PageSize),
                PagingInfo = new PagingInfo
                {
                    CurrentPage = page,
                    ItemsPerPage = PageSize,
                    TotalItems = category == null ? 
                    repository.Adventures.Count() :
                    repository.Adventures.Where(e => 
                        e.Category == category).Count()
                },
                CurrentCategory = category
            });
        
    }
    
}
