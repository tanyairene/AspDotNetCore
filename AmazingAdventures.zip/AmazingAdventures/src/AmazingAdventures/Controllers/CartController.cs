﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using AmazingAdventures.Infrastructure;
using AmazingAdventures.Models;
using AmazingAdventures.Models.ViewModels;

namespace AmazingAdventures.Controllers
{
    public class CartController : Controller
    {
        private IAdventureRepository repository;
        private Cart cart;
        public CartController(IAdventureRepository repo, Cart cartService)
        {
            repository = repo;
            cart = cartService;
        }

        public ViewResult Index(string returnUrl)
        {
            return View(new CartIndexViewModel
            {
                Cart = cart,
                ReturnUrl = returnUrl
            });
        }
        public RedirectToActionResult AddToCart(int adventureId, string returnUrl)
        {
            Adventure adventure = repository.Adventures
                .FirstOrDefault(p => p.AdventureId == adventureId);

            if (adventure != null)
            {
                cart.AddItem(adventure, 1);
                
            }
            return RedirectToAction("Index", new { returnUrl });
        }

        public RedirectToActionResult RemoveFromCart(int adventureId, 
            string returnUrl)
        {
            Adventure adventure = repository.Adventures
                .FirstOrDefault(p => p.AdventureId == adventureId);

            if (adventure != null)
            {
                cart.RemoveLine(adventure);
                
            }
            return RedirectToAction("Index", new { returnUrl });
        }

        
    }
}
