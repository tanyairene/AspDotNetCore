﻿CREATE TABLE [dbo].[Adventures] (
    [AdventureId] INT             IDENTITY (1, 1) NOT NULL,
    [Category]    NVARCHAR (MAX)  NULL,
    [Description] NVARCHAR (MAX)  NULL,
    [Location]    NVARCHAR (MAX)  NULL,
    [Name]        NVARCHAR (MAX)  NULL,
    [Price]       DECIMAL (18, 2) NULL,
    [Image] NCHAR(25) NULL, 
    CONSTRAINT [PK_Adventures] PRIMARY KEY CLUSTERED ([AdventureId] ASC)
);

