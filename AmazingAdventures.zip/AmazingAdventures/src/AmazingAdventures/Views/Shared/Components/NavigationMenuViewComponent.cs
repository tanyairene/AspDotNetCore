﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AmazingAdventures.Models;

namespace AmazingAdventures.Components
{
    public class NavigationMenuViewComponent : ViewComponent
    {
        private IAdventureRepository repository;

        public NavigationMenuViewComponent(IAdventureRepository repo)
        {
            repository = repo;
        }
        public IViewComponentResult Invoke()
        {
            ViewBag.SelectedCategory = RouteData?.Values["category"];
            return View(repository.Adventures
                .Select(x => x.Category)
                .Distinct()
                .OrderBy(x => x));
        }
    }
}
