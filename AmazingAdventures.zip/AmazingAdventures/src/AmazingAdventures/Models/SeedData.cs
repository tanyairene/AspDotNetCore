﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace AmazingAdventures.Models
{
    public static class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            ApplicationDbContext context = app.ApplicationServices
                .GetRequiredService<ApplicationDbContext>();
            if (!context.Adventures.Any())
            {
                context.Adventures.AddRange(
                    new Adventure
                    {
                        Name = "Icelandic Auroras",
                        Location = "Rekjavik, Iceland",
                        Description = "See the Northern Lights from Iceland! Beautiful",
                        Category = "Cold Adventures",
                        Price = 2400m,
                        //Image = "Images/northern-lights-iceland-large.jpg"
                        
                    },
                    new Adventure
                    {
                        Name = "Ride The Rails",
                        Location = "Kangra, India",
                        Description = "The entire route commands glorious views of nature and unveils myriad facets of history, art and culture. The grand spectacle of Kangra Valley begins unfolding after the train crosses Nurpur. Hillocks rise on both sides and as the train moves over the innumerable bridges built across meandering streams, the Dhauladhar begin to gain in prominence. Emerging through Daulatpur tunnel and past the ruins of the old Kangra fort, one is surprised by the change in the landscape.",
                        Category = "Family Fun",
                        Price = 3200m,
                        //Image="Images/Kangra-India-Travel-Getty-large.jpg"
                        
                    },
                    new Adventure
                    {
                        Name="Mushing in Muktuk",
                        Location ="Yukon Territory, Canada",
                        Description= "Sledding across a frozen river topped with untouched snow on a perfectly clear winter day in the Takhini Valley has a profound effect on the human soul.",
                        Category="Cold Adventures",
                        Price =3350m,
                        //Image="Images/muktukDogs.jpg"
                        
                    },
                    new Adventure
                    {
                        Name="Find Venezuela's Lost City",
                        Location ="Venezuela, South America",
                        Description= "A mystic, flat-topped mountain on the Venezuela-Brazil border that perplexed 19th-century explorers and inspired 'The Lost World' novel is attracting ever more modern-day adventurers.",
                        Category="Hot Adventures",
                        Price =2200m,
                        //Image="Images/angel-falls-large.jpg"
                    },
                    new Adventure
                    {
                        Name="African Bulls",
                        Location ="Kenya, Africa",
                        Description="Ride the African bulls in Kenya. Experience a thrilling safari!!!",
                        Category="Hot Adventures",
                        Price =1979m,
                        //Image="Images/AfricanBull.jpg"
                    },
                    new Adventure
                    {
                        Name="Good Times, Galapagos",
                        Location ="Ecuador, South America",
                        Description="See all the amazing wildlife and species you didn't know existed.",
                        Category="Hot Adventures",
                        Price =3550m,
                        //Image="Images/galapagos-tortoise-large.jpg"
                    },
                    new Adventure
                    {
                        Name="Mayan Chichen Itza",
                        Location = "Yucatan, Mexico",
                        Description= "Chichen-Itza, now including one of the new 7 wonders of the world; the Kukulkan Pyramid, is located in the Peninsula of Yucatan, in the Yucatan State; Mexico, between Valladolid and Merida and is just120 km from Merida.",
                        Category="Family Fun",
                        Price =1380m,
                        //Image="Images/maya-chichen-itza-AP-TRAVEL-large.jpg"
                    },
                    new Adventure
                    {
                        Name="Wild, Wild, West",
                        Location ="Utah, United States of America",
                        Description="Experience Native culture AND cowboy culture in the wild west of Utah.",
                        Category="Family Fun",
                        Price =1400m,
                        //Image="Images/tepee-utah-large.jpg"
                    },
                    new Adventure
                    {
                        Name="Crystal Caves",
                        Location ="Naica, Mexico",
                        Description="Come and see the largest crystals known to man as of yet, buried in the caves beneath Naica.",
                        Category="Hot Adventures",
                        Price =2100m,
                        //Image="Images/Naica_14.jpg"
                    },
                    new Adventure
                    {
                        Name="Meet the Chilean Alpacas" ,
                        Location ="Chile, South America",
                        Description= "Chile's climate is as diverse as its geography. Aside from the obviously extreme climatic conditions of the Andes an the Atacama, however, the country enjoys a comfortable temperate climate.",
                        Category="Family Fun",
                        Price =2000m,
                        //Image="Images/chile_2372299a-large.jpg"
                    }

                );
                context.SaveChanges();
            }
        }
    }
}
