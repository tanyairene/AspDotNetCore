﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmazingAdventures.Models
{
    public interface IAdventureRepository
    {
        IEnumerable<Adventure> Adventures { get; }
        void SaveAdventure(Adventure adventure);

        Adventure DeleteAdventure(int adventureId);
    }
}
