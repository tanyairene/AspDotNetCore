﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AmazingAdventures.Models;

namespace AmazingAdventures.Models.ViewModels
{
    public class AdventuresListViewModel
    {
        public IEnumerable<Adventure> Adventures { get; set; }
        public PagingInfo PagingInfo { get; set; }
        public string CurrentCategory { get; set; }

    }
}
