﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmazingAdventures.Models
{
    public class EFAdventureRepository  : IAdventureRepository
    {
        private ApplicationDbContext context;

        public EFAdventureRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }

        public IEnumerable<Adventure> Adventures => context.Adventures;

        public void SaveAdventure(Adventure adventure)
        {
            if(adventure.AdventureId == 0)
            {
                context.Adventures.Add(adventure);
            }
            else
            {
                Adventure dbEntry = context.Adventures
                    .FirstOrDefault(p => p.AdventureId == adventure.AdventureId);
                if(dbEntry != null)
                {
                    dbEntry.Name = adventure.Name;
                    dbEntry.Description = adventure.Description;
                    dbEntry.Location = adventure.Location;
                    dbEntry.Price = adventure.Price;
                    dbEntry.Category = adventure.Category;
                }
            }
            context.SaveChanges();
        }
        public Adventure DeleteAdventure(int adventureId)
        {
            Adventure dbEntry = context.Adventures
                .FirstOrDefault(p => p.AdventureId == adventureId);
            if(dbEntry != null)
            {
                context.Adventures.Remove(dbEntry);
                context.SaveChanges();
            }
            return dbEntry;
        }
    }
}
