﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmazingAdventures.Models
{
    public class Cart
    {
        private List<CartLine> lineCollection = new List<CartLine>();

        public virtual void AddItem(Adventure adventure, int quantity)
        {
            CartLine line = lineCollection
                .Where(p => p.Adventure.AdventureId == adventure.AdventureId)
                .FirstOrDefault();


            if (line == null)
            {
                lineCollection.Add(new CartLine
                {
                    Adventure = adventure,
                    Quantity = quantity
                });

            }
            else
            {
                line.Quantity += quantity;
            }
        }

        public virtual void RemoveLine(Adventure adventure) =>
            lineCollection.RemoveAll(l => l.Adventure.AdventureId == adventure.AdventureId);

        public virtual decimal ComputeTotalValue() =>
            lineCollection.Sum(e => e.Adventure.Price * e.Quantity);

        public virtual void Clear() => lineCollection.Clear();
        public virtual IEnumerable<CartLine> Lines => lineCollection;
    }

    public class CartLine
    {
        public int CartLineID { get; set; }
        public Adventure Adventure { get; set; }
        public int Quantity { get; set; }
    }
}