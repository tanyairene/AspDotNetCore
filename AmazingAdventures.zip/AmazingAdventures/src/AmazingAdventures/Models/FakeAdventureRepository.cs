﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AmazingAdventures.Models
{
    public class FakeAdventureRepository  /*: IAdventureRepository */
    {
        public IEnumerable<Adventure> Adventures => new List<Adventure>
        {
            new Adventure { Name="Mushing in Muktuk", Location="Yukon Territory, Canada", },
            new Adventure { Name="Icelandic Auroras", Location="Reykjavík, Iceland" },
            new Adventure { Name="Ride The Rails", Location="Kangra, India" }
        };
    }
}
