﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using AmazingAdventures.Models;

namespace AmazingAdventures.Migrations
{
    [DbContext(typeof(ApplicationDbContext))]
    [Migration("20170307140049_Orders")]
    partial class Orders
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.0.0-rtm-21431")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("AmazingAdventures.Models.Adventure", b =>
                {
                    b.Property<int>("AdventureId")
                        .ValueGeneratedOnAdd();

                    b.Property<string>("Category");

                    b.Property<string>("Description");

                    b.Property<string>("Location");

                    b.Property<string>("Name");

                    b.Property<decimal>("Price");

                    b.HasKey("AdventureId");

                    b.ToTable("Adventures");
                });
        }
    }
}
